﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


//La información general sobre un ensamblaje se controla a través del siguiente conjunto de atributos.

[assembly: AssemblyTitle("Tetris GAME")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Tetris GAME")]
[assembly: AssemblyCopyright("Copyright ArcadeMania©  2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("3c87ac93-e3c6-43e8-84ff-9d6eb4b7842d")]

// La información de versión de un ensamblado consta de los siguientes cuatro valores:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
