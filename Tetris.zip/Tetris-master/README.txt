Gameplay: https://youtu.be/Rtz6i2MRCnA
